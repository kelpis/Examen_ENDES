import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SelectorDeRegalosTest {

    @Test
    void jugueteConstruccion(){
        String regalo1 = SelectorDeRegalos.seleccionarRegalo(101,11);
        assertEquals("Juguete de construcción", regalo1);



    }
    @Test
    void libroAventura(){
        String regalo1 = SelectorDeRegalos.seleccionarRegalo(45,18);
        assertEquals("Libro de aventuras", regalo1);



    }



}